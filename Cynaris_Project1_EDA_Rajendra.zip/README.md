# Indian Retail & E-Commerce Sales — Exploratory Data Analysis (EDA)

**Candidate:** Rajendra  
**Role:** Data Analyst Intern — Project 1 (Beginner)  
**Platform:** Cynaris Internship Portal  
**Tech Stack:** Python 3, Pandas, Matplotlib  

## 1. Project Overview
This project performs a complete end-to-end Exploratory Data Analysis (EDA) on an Indian retail and e-commerce sales dataset covering **2,400 transactions across FY 2025–26** (10 Tier-1 and Tier-2 Indian cities, 5 product categories, and 5 payment modes). The objective is to uncover revenue drivers, margin leaks, payment behavior, and regional opportunities, distilled into **5 actionable business findings**.

## 2. Repository Structure
```text
project_submission/
├── data/
│   └── indian_retail_sales_fy26.csv       # Raw dataset (2,402 rows including anomalies for cleaning)
├── charts/
│   ├── 01_monthly_sales_profit_trend.png
│   ├── 02_category_revenue_vs_margin.png
│   ├── 03_discount_margin_erosion.png
│   ├── 04_payment_mode_and_returns.png
│   └── 05_city_tier_performance.png
├── eda_analysis.py                        # Modular data cleaning, KPI computation & Matplotlib script
├── requirements.txt                       # Python dependencies
├── README.md                              # Project documentation
└── Business_Insight_Report_Rajendra.pdf   # Executive 5-Finding Business Insight Report
```

## 3. How to Run
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Execute the EDA pipeline:
   ```bash
   python eda_analysis.py
   ```
   This cleans the raw CSV (deduplicating rows, standardizing casing, imputing missing discount values), prints headline KPIs, and regenerates all 5 charts in `charts/`.

## 4. Summary of 5 Key Business Findings
1. **Festive Quarter Surge (Oct–Nov):** October and November alone generate **24.6% (₹71.78 Lakhs)** of annual net sales, though higher festive discounting tempers net profit conversion.
2. **Volume vs. Margin Trade-off:** **Electronics & Accessories** drives **68.8% of total revenue (₹200.45 Lakhs)** at a thin **6.9% net margin**, whereas **Beauty & Personal Care (22.6% margin)** and **Fashion & Apparel (16.9% margin)** deliver superior unit profitability.
3. **Discount Cliff Above 30%:** Orders discounted at **0–10%** average a **15.1% profit margin**, while discounts exceeding **30%** compress average margin down to **9.1%**—a 600 bps drop.
4. **UPI Scale vs. COD Return Risk:** **UPI accounts for 49.9% of all orders** with low return rates (~8.5%), whereas **Cash on Delivery (COD)** suffers a **16.6% return/RTO rate** (nearly double prepaid orders at **8.7%**).
5. **Metro Concentration & Tier-2 Growth Headroom:** **Mumbai, Delhi NCR, and Bengaluru** contribute **52.4% of total revenue**, while Tier-2 cities (Jaipur, Kochi, Indore, Lucknow) account for **21.3%** and represent high-upside expansion markets if prepaid checkout incentives are introduced.
