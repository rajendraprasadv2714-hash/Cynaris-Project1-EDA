"""
Exploratory Data Analysis (EDA) — Indian Retail & E-Commerce Sales (FY 2025-26)
Author: Rajendra
Track: Cynaris Data Analyst Intern — Project 1 (Beginner)
Libraries: Python, Pandas, Matplotlib
"""

import os
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick

# Configure clean publication-ready Matplotlib styling
plt.rcParams["figure.dpi"] = 150
plt.rcParams["font.sans-serif"] = "DejaVu Sans"
plt.rcParams["axes.edgecolor"] = "#CBD5E1"
plt.rcParams["axes.linewidth"] = 0.8


def load_and_clean_data(filepath: str) -> pd.DataFrame:
    """Load raw CSV, deduplicate, standardize text fields, and impute missing values."""
    df = pd.read_csv(filepath)
    print(f"Raw dataset shape: {df.shape}")

    # 1. Remove exact duplicate transactions
    df = df.drop_duplicates().copy()

    # 2. Standardize categorical casing
    df["City"] = df["City"].str.strip().str.title()
    df["Payment_Mode"] = df["Payment_Mode"].replace({"upi": "UPI"})

    # 3. Impute missing Discount_Pct using category-level median
    df["Discount_Pct"] = df["Discount_Pct"].fillna(
        df.groupby("Category")["Discount_Pct"].transform("median")
    )

    # 4. Parse dates and engineer temporal features
    df["Order_Date"] = pd.to_datetime(df["Order_Date"])
    df["Month_Num"] = df["Order_Date"].dt.month
    df["Month_Label"] = df["Order_Date"].dt.strftime("%b %Y")
    df["Profit_Margin_Pct"] = (df["Profit_INR"] / df["Net_Sales_INR"]) * 100

    print(f"Cleaned dataset shape: {df.shape}")
    return df


def compute_kpis(df: pd.DataFrame) -> dict:
    """Compute headline executive KPIs and key business metrics."""
    total_revenue = df["Net_Sales_INR"].sum()
    total_profit = df["Profit_INR"].sum()
    overall_margin = (total_profit / total_revenue) * 100
    aov = df["Net_Sales_INR"].mean()
    return_rate = (df["Returned"] == "Yes").mean() * 100

    # Festive Oct-Nov share
    festive_rev = df[df["Month_Num"].isin([10, 11])]["Net_Sales_INR"].sum()
    festive_share = (festive_rev / total_revenue) * 100

    # UPI share
    upi_share = (df["Payment_Mode"] == "UPI").mean() * 100

    # COD vs Prepaid return rates
    cod_return = (df[df["Payment_Mode"] == "Cash on Delivery (COD)"]["Returned"] == "Yes").mean() * 100
    prepaid_return = (df[df["Payment_Mode"] != "Cash on Delivery (COD)"]["Returned"] == "Yes").mean() * 100

    # Discount > 25% margin
    high_disc_margin = df[df["Discount_Pct"] > 25]["Profit_Margin_Pct"].mean()
    low_disc_margin = df[df["Discount_Pct"] <= 15]["Profit_Margin_Pct"].mean()

    return {
        "total_orders": len(df),
        "total_revenue_lakhs": total_revenue / 1e5,
        "total_profit_lakhs": total_profit / 1e5,
        "overall_margin_pct": overall_margin,
        "aov_inr": aov,
        "return_rate_pct": return_rate,
        "festive_share_pct": festive_share,
        "upi_share_pct": upi_share,
        "cod_return_pct": cod_return,
        "prepaid_return_pct": prepaid_return,
        "high_disc_margin_pct": high_disc_margin,
        "low_disc_margin_pct": low_disc_margin,
    }


def generate_visualizations(df: pd.DataFrame, output_dir: str = "charts") -> None:
    """Generate 5 core Matplotlib charts supporting the 5 business insights."""
    os.makedirs(output_dir, exist_ok=True)
    palette = ["#1E3A8A", "#0D9488", "#D97706", "#64748B", "#DC2626"]

    # Chart 1: Monthly Revenue & Profit Trend (FY 2025-26)
    monthly = (
        df.sort_values("Order_Date")
        .groupby("Month_Label", sort=False)
        .agg(Revenue=("Net_Sales_INR", "sum"), Profit=("Profit_INR", "sum"))
        .reset_index()
    )
    fig, ax1 = plt.subplots(figsize=(9, 4.2))
    bars = ax1.bar(monthly["Month_Label"], monthly["Revenue"] / 1e5, color="#1E3A8A", alpha=0.85, label="Net Sales (₹ Lakhs)")
    ax1.set_ylabel("Net Sales (₹ Lakhs)", color="#1E3A8A", fontweight="bold")
    ax1.tick_params(axis="x", rotation=35)
    ax1.grid(axis="y", linestyle="--", alpha=0.4)
    ax1.spines["top"].set_visible(False)

    ax2 = ax1.twinx()
    ax2.plot(monthly["Month_Label"], monthly["Profit"] / 1e5, color="#D97706", marker="o", linewidth=2.2, label="Net Profit (₹ Lakhs)")
    ax2.set_ylabel("Net Profit (₹ Lakhs)", color="#D97706", fontweight="bold")
    ax2.spines["top"].set_visible(False)
    plt.title("Finding 1: Festive Quarter (Oct–Nov) Drives Peak Monthly Sales & Profit", fontsize=11, fontweight="bold", pad=12)
    fig.tight_layout()
    plt.savefig(f"{output_dir}/01_monthly_sales_profit_trend.png")
    plt.close()

    # Chart 2: Category Revenue vs Profit Margin Comparison
    cat_summary = (
        df.groupby("Category")
        .agg(Revenue=("Net_Sales_INR", "sum"), Profit=("Profit_INR", "sum"))
        .assign(Margin=lambda x: (x["Profit"] / x["Revenue"]) * 100)
        .sort_values("Revenue", ascending=True)
    )
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(9.5, 4.0))
    ax1.barh(cat_summary.index, cat_summary["Revenue"] / 1e5, color="#1E3A8A")
    ax1.set_title("Net Sales by Category (₹ Lakhs)", fontsize=10, fontweight="bold")
    ax1.grid(axis="x", linestyle="--", alpha=0.4)
    ax1.spines[["top", "right"]].set_visible(False)

    ax2.barh(cat_summary.index, cat_summary["Margin"], color="#0D9488")
    ax2.set_title("Net Profit Margin (%)", fontsize=10, fontweight="bold")
    ax2.xaxis.set_major_formatter(mtick.PercentFormatter())
    ax2.grid(axis="x", linestyle="--", alpha=0.4)
    ax2.spines[["top", "right"]].set_visible(False)
    fig.suptitle("Finding 2: Electronics Leads Revenue, While Beauty & Home Deliver Highest Margins", fontsize=11, fontweight="bold")
    fig.tight_layout()
    plt.savefig(f"{output_dir}/02_category_revenue_vs_margin.png")
    plt.close()

    # Chart 3: Discount Bracket vs Profit Margin Erosion
    df["Discount_Band"] = pd.cut(
        df["Discount_Pct"],
        bins=[-0.1, 10, 20, 30, 50],
        labels=["0–10%", "11–20%", "21–30%", ">30%"]
    )
    disc_summary = df.groupby("Discount_Band", observed=False)["Profit_Margin_Pct"].mean()
    fig, ax = plt.subplots(figsize=(8, 4.0))
    colors = ["#0D9488", "#1E3A8A", "#D97706", "#DC2626"]
    bars = ax.bar(disc_summary.index.astype(str), disc_summary.values, color=colors, width=0.52)
    ax.axhline(0, color="#334155", linewidth=1)
    ax.set_ylabel("Average Profit Margin (%)")
    ax.set_xlabel("Discount Tier Applied")
    ax.yaxis.set_major_formatter(mtick.PercentFormatter())
    ax.grid(axis="y", linestyle="--", alpha=0.4)
    ax.spines[["top", "right"]].set_visible(False)
    for b in bars:
        val = b.get_height()
        ax.text(b.get_x() + b.get_width() / 2, val + (0.6 if val >= 0 else -1.5), f"{val:.1f}%", ha="center", fontweight="bold", fontsize=9)
    plt.title("Finding 3: Discounts Above 25–30% Trigger Severe Margin Compression", fontsize=11, fontweight="bold", pad=12)
    fig.tight_layout()
    plt.savefig(f"{output_dir}/03_discount_margin_erosion.png")
    plt.close()

    # Chart 4: Payment Mode Share & Return Rate Comparison
    pay_summary = (
        df.groupby("Payment_Mode")
        .agg(Orders=("Order_ID", "count"), Return_Rate=("Returned", lambda s: (s == "Yes").mean() * 100))
        .sort_values("Orders", ascending=False)
    )
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(9.5, 4.0))
    ax1.bar(pay_summary.index, (pay_summary["Orders"] / len(df)) * 100, color="#1E3A8A")
    ax1.set_title("Order Share by Payment Mode (%)", fontsize=10, fontweight="bold")
    ax1.tick_params(axis="x", rotation=25)
    ax1.yaxis.set_major_formatter(mtick.PercentFormatter())
    ax1.grid(axis="y", linestyle="--", alpha=0.4)
    ax1.spines[["top", "right"]].set_visible(False)

    bar_colors = ["#DC2626" if "COD" in idx else "#0D9488" for idx in pay_summary.index]
    ax2.bar(pay_summary.index, pay_summary["Return_Rate"], color=bar_colors)
    ax2.set_title("Return / RTO Rate by Payment Mode (%)", fontsize=10, fontweight="bold")
    ax2.tick_params(axis="x", rotation=25)
    ax2.yaxis.set_major_formatter(mtick.PercentFormatter())
    ax2.grid(axis="y", linestyle="--", alpha=0.4)
    ax2.spines[["top", "right"]].set_visible(False)
    fig.suptitle("Finding 4: UPI Dominates Checkout Volume, Whereas COD Drives Disproportionate Returns", fontsize=11, fontweight="bold")
    fig.tight_layout()
    plt.savefig(f"{output_dir}/04_payment_mode_and_returns.png")
    plt.close()

    # Chart 5: Top 10 Indian Cities Revenue & Tier Performance
    city_summary = (
        df.groupby(["City", "City_Tier"])["Net_Sales_INR"]
        .sum()
        .reset_index()
        .sort_values("Net_Sales_INR", ascending=True)
    )
    fig, ax = plt.subplots(figsize=(8.5, 4.2))
    c_colors = ["#1E3A8A" if t == "Tier-1" else "#D97706" for t in city_summary["City_Tier"]]
    ax.barh(city_summary["City"], city_summary["Net_Sales_INR"] / 1e5, color=c_colors)
    ax.set_xlabel("Net Sales (₹ Lakhs)")
    ax.grid(axis="x", linestyle="--", alpha=0.4)
    ax.spines[["top", "right"]].set_visible(False)
    plt.title("Finding 5: Top 3 Metros Generate Half of Total Sales; Tier-2 Cities Show Fast Basket Potential", fontsize=10.5, fontweight="bold", pad=12)
    fig.tight_layout()
    plt.savefig(f"{output_dir}/05_city_tier_performance.png")
    plt.close()


if __name__ == "__main__":
    cleaned_df = load_and_clean_data("data/indian_retail_sales_fy26.csv")
    kpis = compute_kpis(cleaned_df)
    for k, v in kpis.items():
        print(f"{k}: {v:.2f}")
    generate_visualizations(cleaned_df, output_dir="charts")
    print("EDA execution completed successfully.")
